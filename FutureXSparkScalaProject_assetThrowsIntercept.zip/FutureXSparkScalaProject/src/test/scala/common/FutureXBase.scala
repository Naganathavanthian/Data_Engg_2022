package common

import org.scalatest.flatspec.AnyFlatSpec

abstract class FutureXBase extends AnyFlatSpec {

}
